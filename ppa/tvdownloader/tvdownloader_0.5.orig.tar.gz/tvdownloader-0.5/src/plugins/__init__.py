#!/usr/bin/env python
# -*- coding:Utf-8 -*-

#~ import sys
#~ sys.path[ :0 ] = [ '../', '../lib/' ] # On ajoute des repertoires au path
