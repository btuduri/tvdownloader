#!/bin/bash

cd __DATADIR__/tvdownloader/
python main.py