#!/usr/bin/env python
# -*- coding:Utf-8 -*-

###########
# Modules #
###########

import unittest

from PreferencesTests import PreferencesTests
from HistoriqueTests import HistoriqueTests

#########
# Debut #
#########

unittest.main()